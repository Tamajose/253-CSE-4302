#include "Products.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

string generateRandomString(int length){
    string randomString;
    const char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    int alphabetSize = sizeof(alphabet) - 1;
    srand(static_cast<unsigned int>(time(0)));
    for (int i = 0; i < length; ++i){
        randomString += alphabet[rand() % alphabetSize];
    }
    return randomString;
}

int randomInRange(int min, int max){
    if(min>max){
        swap(min, max);
    }
    return rand()%(max-min+1)+min;
}

double randomInRange(double min, double max){
    if(min>max){
        swap(min, max);
    }
    double randomFraction = static_cast<double>(rand())/RAND_MAX;
    return min+randomFraction*(max-min);
}

void generateInformationRandom(Products &p){
    p.setname(generateRandomString(randomInRange(3,7)));
    p.setcategory(generateRandomString(randomInRange(3,7)));
    p.setdescription(generateRandomString(randomInRange(3,7)));
    p.setamount(randomInRange(0,100));
    p.setregular(randomInRange(0.00, 99.99));
    p.setdiscount(randomInRange(0.00, 9.99));
}

void Products::setname(const string &s){
    name = s;
}

void Products::setcategory(const string &s){
    category = s;
}

void Products::setdescription(const string &s){
    description = s;
}

void Products::setamount(int n){
    amount = n;
}

void Products::setregular(float n){
    regularprice = n;
}

void Products::setdiscount(float n){
    discountrate = n;
}

void EditInformationByKeyboard(Products &p){
    string name, category, description;
    int amount;
    float regular, discount;
    cout << "Product Name: ";
    getline(cin, name);
    p.setname(name);
    cout << "Product Category: ";
    getline(cin, category);
    p.setcategory(category);
    cout << "Product Description: ";
    getline(cin, description);
    p.setdescription(description);
    cout << "Product Amount: ";
    cin >> amount;
    p.setamount(amount);
    cout << "Regular Price: ";
    cin >> regular;
    p.setregular(regular);
    cout << "Discount Rate: ";
    cin >> discount;
    p.setdiscount(discount);
}

string Products::getname(){
    return name;
}

string Products::getcategory(){
    return category;
}

string Products::getdescription(){
    return description;
}

int Products::getamount(){
    return amount;
}

float Products::getregular(){
    return regularprice;
}

float Products::getdiscount(){
    return discountrate;
}

void Products::PurchaseProducts(int n){
    if(amount<n){
        amount = 0;
    }
    else amount -= n;
}

void Products::RestockProduct(int n){
    amount += n;
}

double Products::calculateDiscount(int n){
    double total;
    if(n>=5 && n<10 && n<amount){
        total = (discountrate/100) * regularprice * n;
    }
    else if(n>=10 && n<amount){
        total = (discountrate/100) * regularprice * n;
    }
    else if(n>amount){
        if(amount>=5 && amount<10){
            total = (discountrate/100) * regularprice * amount;
        }
        if(amount>=10){
            total = (discountrate/100) * regularprice * amount;
        }
    }
    return total;
}